#ifndef ADATKEZELES_H_INCLUDED
#define ADATKEZELES_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

extern bool aktiv_ab;
typedef struct Nev
{
    char fname[30];
    char lname[30];
}Nev;

typedef struct Cim
{
    char addr[80];
    char atyp[20];
    char num[10];
    char city[50];
    char zip[8];
}Cim;

typedef struct Rekord
{
    Nev name;
    char ctel[20];
    char htel[20];
    char wtel[20];
    Cim address;
    Cim waddr;
    char ceg[80];
    char osztaly[80];
    char beosztas[50];
    char email[30];
    char bday[9];
    struct Rekord* kov;
}Rekord;

void felszabaditas(Rekord* ab);

Rekord* ures_ab();

Rekord* uj_rekord(Rekord* ab);

void uj_feltolt(Rekord* uj);

void sorbol_feltolt(Rekord* uj, char* sor);

Rekord* betoltes(Rekord* ab);

void init(Rekord* uj);

void fajlba_kiir(Rekord* ab);

int szerkeszt();

int uj_adatbazis(Rekord* ab);

void kereses(Rekord* ab);

int menuvalaszt(int max);

void listazas(Rekord* ab);

void menulista();

char kitoltes(char* mezo);

void sikertelen(char* hiba);

void pre();

bool dbcheck(Rekord* ab);

void nofunc();

#endif // ADATKEZELES_H_INCLUDED
