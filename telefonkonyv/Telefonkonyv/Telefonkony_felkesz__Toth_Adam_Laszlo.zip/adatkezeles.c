#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "adatkezeles.h"

void felszabaditas(Rekord* ab)
{
    while(ab != NULL)
    {
        Rekord* next = ab->kov;
        free(ab);
        ab = next;
        printf("Sikeres memoria felszabaditas\n");
    }


}

Rekord* ures_ab()
{
    Rekord* uj;
    uj = (Rekord*) malloc(sizeof(Rekord));
    uj->kov = NULL;
    aktiv_ab = true;
    return uj;
}

Rekord* uj_rekord(Rekord* ab)
{
    if(dbcheck(ab))
    {
        return NULL;
    }
    else
    {
        Rekord* uj;
        uj = (Rekord*) malloc(sizeof(Rekord));
        uj->kov = ab;
        return uj;
    }

}

void uj_feltolt(Rekord* uj)
{
    init(uj);
    printf("Adjon meg egy nevet(vezeteknev keresztnev): ");
    scanf("%s %s",uj->name.lname,uj->name.fname);
    char valasz = kitoltes("Mobiltelefonszam");
    switch(valasz)
    {
        case 'y':
        {
            printf("Adjon meg egy mobiltelefonszamot: ");
            scanf("%s",uj->ctel);
        }
        break;
        case 'x':
            return;
        break;
        default:printf("Mezo kihagyva\n");

        break;
    }
    valasz = kitoltes("Otthoni telefonszam");
    switch(valasz)
    {
        case 'y':
        {
            printf("Adjon meg egy otthoni telefonszamot: ");
            scanf("%s",uj->htel);
        }
        break;
        case 'x':
            return;
        break;
        default:printf("Mezo kihagyva\n");
        break;
    }
    valasz = kitoltes("Munkahelyi telefonszam");
    switch(valasz)
    {
        case 'y':
        {
            printf("Adjon meg egy munkahelyi telefonszamot: ");
            scanf("%s",uj->wtel);
        }
        break;
        case 'x':
            return;
        break;
        default:printf("Mezo kihagyva\n");
        break;
    }
    valasz = kitoltes("Otthoni lakcim");
    switch(valasz)
    {
        case 'y':
        {
            printf("Adjon meg egy otthoni lakcimet(kozterulet_neve kozt_tipusa hazszam varos irsz): ");
            scanf("%s %s %s %s %s",uj->address.addr,uj->address.atyp,uj->address.num,uj->address.city,uj->address.zip);
        }
        break;
        case 'x':
            return;
        break;
        default:printf("Mezo kihagyva\n");
        break;
    }
    valasz = kitoltes("Munkahelyi cim");
    switch(valasz)
    {
        case 'y':
        {
            printf("Adjon meg egy munkahelyi cimet(kozterulet_neve kozt_tipusa hazszam varos irsz): ");
            scanf("%s %s %s %s %s",uj->waddr.addr,uj->waddr.atyp,uj->waddr.num,uj->waddr.city,uj->waddr.zip);
        }
        break;
        case 'x':
            return;
        break;
        default:printf("Mezo kihagyva\n");
        break;
    }
    valasz = kitoltes("Munkahely");
    switch(valasz)
    {
        case 'y':
        {
            printf("Adjon meg egy munkahelyet(cegnev osztaly): ");
            scanf("%s %s",uj->ceg,uj->osztaly);
        }
        break;
        case 'x':
            return;
        break;
        default:printf("Mezo kihagyva\n");
        break;
    }
    valasz = kitoltes("Beosztas");
    switch(valasz)
    {
        case 'y':
        {
            printf("Adjon meg egy beosztast: ");
            scanf("%s",uj->beosztas);
        }
        break;
        case 'x':
            return;
        break;
        default:printf("Mezo kihagyva\n");
        break;
    }
    valasz = kitoltes("E-mail cim");
    switch(valasz)
    {
        case 'y':
        {
            printf("Adjon meg egy e-mail cimet: ");
            scanf("%s",uj->email);
        }
        break;
        case 'x':
            return;
        break;
        default:printf("Mezo kihagyva\n");
        break;
    }
    valasz = kitoltes("Szuletesnap");
    switch(valasz)
    {
        case 'y':
        {
            printf("Adjon meg egy szuletesnapot (yyyymmdd): ");
            scanf("%s",uj->bday);
        }
        break;
        case 'x':
            return;
        break;
        default:printf("Mezo kihagyva\n");
        break;
    }
}

void sorbol_feltolt(Rekord* uj, char* sor)
{
    sscanf(sor,"%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%s",uj->name.lname,uj->name.fname,uj->ctel,uj->htel,uj->wtel,uj->address.addr,uj->address.atyp,uj->address.num,uj->address.city,uj->address.zip,uj->waddr.addr,uj->waddr.atyp,uj->waddr.num,uj->waddr.city,uj->waddr.zip,uj->ceg,uj->osztaly,uj->beosztas,uj->email,uj->bday);
}

Rekord* betoltes(Rekord* ab)
{
    printf("Kerem adja meg a beolvasni kivant fajl nevet!(kiterjesztes jeloles nelkul)\n");
    char* fajlnev[20];
    scanf("%s",fajlnev);
    strcat(&fajlnev,".csv");
    FILE* be;
    be = fopen(fajlnev,"r");
    if(be != NULL)
    {
        printf("\nSikeres fajlnyitas!\n\n");
        char sor[501];
        fgets(sor,500,be);
        Rekord* elozo = ab;
        Rekord* uj;
        while(fgets(sor,500,be) != NULL)
        {
            uj = (Rekord*) malloc(sizeof(Rekord));
            sorbol_feltolt(uj,sor);
            uj->kov = elozo;
            elozo = uj;
        }
        fclose(be);
        return uj;
    }
    else
    {
        sikertelen("fajlnyitas");
        return;

    }
}

void init(Rekord* uj)
{
    strcpy(uj->name.fname,"nincs");
    strcpy(uj->name.lname,"nincs");
    strcpy(uj->address.atyp,"nincs");
    strcpy(uj->address.city,"nincs");
    strcpy(uj->address.num,"nincs");
    strcpy(uj->address.zip,"nincs");
    strcpy(uj->address.addr,"nincs");
    strcpy(uj->bday,"nincs");
    strcpy(uj->beosztas,"nincs");
    strcpy(uj->ceg,"nincs");
    strcpy(uj->ctel,"nincs");
    strcpy(uj->email,"nincs");
    strcpy(uj->htel,"nincs");
    strcpy(uj->osztaly,"nincs");
    strcpy(uj->waddr.addr,"nincs");
    strcpy(uj->waddr.atyp,"nincs");
    strcpy(uj->waddr.city,"nincs");
    strcpy(uj->waddr.num,"nincs");
    strcpy(uj->waddr.zip,"nincs");
    strcpy(uj->wtel,"nincs");
}

void fajlba_kiir(Rekord* ab)
{
    if(dbcheck(ab))
    {
        return;
    }
    printf("Adjon meg egy fajlnevet!(kiterjesztes jeloles nelkul)\n");
    char fajlnev[20];
    scanf("%s",&fajlnev);
    strcat(&fajlnev,".csv");
    FILE* ki;
    ki = fopen(fajlnev,"w");
    if(ki != NULL)
    {
        fprintf(ki,"Vezeteknev,Keresztnev,Mobil szam,Otthoni szam,Munkahelyi szam,Lakcim_kozterulet,Lakcim_kozt_tip,Lakcim_hazszam,Lakcim_varos,Lakcim_irsz,");
        fprintf(ki,"Mhely_kozterulet,Mhely_kozt_tip,Mhely_hazszam,Mhely_varos,Mhely_irsz,Ceg,Osztaly,Beosztas,Email,Szuletesnap");
        fprintf(ki,"\n");
        Rekord* mozgo = ab;
        while(mozgo->kov != NULL)
        {
            fprintf(ki,"%s,%s,",mozgo->name.lname,mozgo->name.fname);
            fprintf(ki,"%s,%s,%s,",mozgo->ctel,mozgo->htel,mozgo->wtel);
            fprintf(ki,"%s,%s,%s,%s,%s,",mozgo->address.addr,mozgo->address.atyp,mozgo->address.num,mozgo->address.city,mozgo->address.zip);
            fprintf(ki,"%s,%s,%s,%s,%s,",mozgo->waddr.addr,mozgo->waddr.atyp,mozgo->waddr.num,mozgo->waddr.city,mozgo->waddr.zip);
            fprintf(ki,"%s,%s,%s,%s,%s",mozgo->ceg,mozgo->osztaly,mozgo->beosztas,mozgo->email,mozgo->bday);
            fprintf(ki,"\n");
            mozgo = mozgo->kov;
        }
        fclose(ki);
        printf("Sikeres mentes!\n");
    }
    else
    {
        sikertelen("fajlletrehozas");
        return;
    }

}

int szerkeszt()
{
    printf("****************************************\n");
    printf("[Almenu: Szerkesztes]\n\n");
    printf("[1] Uj bejegyzes\n");
    printf("[2] Meglevo modositasa\n");
    printf("[3] Bejegyzes torlese\n");
    printf("[4] Vissza a fomenube\n\n");
    return menuvalaszt(4);
}
int uj_adatbazis(Rekord* ab)
{
    if(aktiv_ab && ab->kov != NULL)
    {
        printf("Szeretne menteni a jelenlegi adatbazist?\n1 igen/2 nem\n\n");
        int val =menuvalaszt(2);
        if(val == 1)
        {
            fajlba_kiir(ab);
        }
        felszabaditas(ab);
        ab->kov = NULL;
        ab = NULL;
        aktiv_ab = false;
    }
    printf("****************************************\n");
    printf("[Almenu: Uj adatbazis]\n\n");
    printf("[1] Beolvasas fajlbol\n");
    printf("[2] Ures adatbazis letrehozasa\n");
    printf("[3] Vissza a fomenube\n\n");

    return menuvalaszt(3);

}

void parlista()
{
    printf("[1] [Nev]\n");
    printf("[2] Telefonszam\n");
    printf("[3] Iranyitoszam\n");
    printf("[4] Telepules\n");
    printf("[5] Munkahely\n");
}

bool helyettesito(char *be, char * c)
{
    if (*be=='*'&&*(be+1)!='\0'&&*c=='\0')
    {
        return false;
    }
    if (*be=='\0'&&*c=='\0')
    {
        return true;
    }
    if (*be==*c)
    {
        return helyettesito(be+1,c+1);
    }
    if (*be == '*')
    {
        return helyettesito(be+1,c)||helyettesito(be,c+1);
    }
    return false;
}

void hbejar(Rekord* ab)
{
    printf("Adjon meg egy nevet vagy nevreszletet! (* helyettesito karakterrel)\n");
    char nev[40];
    getchar();
    gets(nev);
    Rekord* mozgo = ab;
    bool talalat = 0;
    while(mozgo->kov != NULL && !talalat)
    {
        char cn[40];
        strcat(cn,mozgo->name.lname);
        strcat(cn," ");
        strcat(cn,mozgo->name.fname);
        printf("%s\n",cn);
        talalat = helyettesito(nev,cn);
        mozgo = mozgo->kov;
    }
    if(mozgo != NULL)
    {
        printf("%s %s\n",mozgo->name.lname,mozgo->name.fname);
    }
}

void kereses(Rekord* ab)
{
    if(dbcheck(ab))
    {
        return;
    }
    printf("Milyen parameter alapjan szeretne keresni?\n");
    parlista();
    int val = menuvalaszt(5);
    switch(val)
    {
        case 1: hbejar(ab);
        break;
        case 2:;
        break;
        case 3:;
        break;
        case 4:;
        break;
        case 5:;
        break;
        default:;
        break;
    }
}

int menuvalaszt(int max)
{
    printf("Menupont kivalasztasa a sorszam begepelesevel lehetseges.\n\n");
    printf("Valasztott menupont szama: \n");
    int sel;
    while(scanf("%d",&sel) != 1)
    {
        printf("Ervenytelen menupont!\n1 es %d kozotti szamot adjon meg!\n\n",max);
        printf("Valasztott menupont szama: \n");
        getchar();
    }

    while(sel < 1 || sel > max)
    {
        printf("Ervenytelen menupont!\n1 es %d kozotti szamot adjon meg!\n\n",max);
        printf("Valasztott menupont szama: \n");
        getchar();
        scanf("%d",&sel);
    }
    return sel;
}

void listazas(Rekord* ab)
{
    if(dbcheck(ab))
    {
        return;
    }
    Rekord* mozgo = ab;
    printf("Jelenleg az adatbazisban szereplo nevek:\n");
    while(mozgo->kov != NULL)
    {
        printf("%s %s\n",mozgo->name.lname,mozgo->name.fname);
        mozgo = mozgo->kov;
    }
    pre();
}

void menulista()
{
    printf("****************************************\n");
    printf("[Fomenu: Telefonkonyv]\n\n");
    printf("[1] Uj adatbazis letrehozasa\n");
    printf("[2] Adatbazis listazasa\n");
    printf("[3] Kereses az adatbazisban\n");
    printf("[4] Adatbazis szerkesztese\n");
    printf("[5] Adatbazis mentese\n");
    printf("[6] Exportalas vCard fajlba\n");
    printf("[7] Kilepes\n\n");
}

char kitoltes(char* mezo)
{
    printf("\nSzeretned kitolteni a kovetkezo mezot: %s?\n\n",mezo);
    printf("y: igen\nx: feltoltes befejezese\nn: mezo atugrasa\n");
    char valasz;
    getchar();
    scanf("%c",&valasz);
    return valasz;
}

void pre()
{
    printf("A tovabblepeshez nyomja meg az Entert!\n");
    getchar();
    getchar();

}

void sikertelen(char* hiba)
{
    printf("Sikertelen %s!\n",hiba);
    pre();
}

bool dbcheck(Rekord* ab)
{
    if(!aktiv_ab)
    {
        printf("\nJelenleg nincs aktiv adatbazis!\n");
        pre();
        return 1;
    }
    if(ab->kov == NULL)
    {
        printf("\nAz adatbazis meg nem tartalmaz elemeket.\n");
        pre();
        return 1;
    }
    return 0;
}

void nofunc()
{
    printf("Sajnos ez a funkcio meg nem kerult implementalasra.\n->Visszateres a fomenube.\n");
    pre();
}

